package org.flipkart.com.tests;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.io.IOException;

public class LoginTest extends BaseTest{

//    @Test
//    public void closeLoginDialogueBox(){
//        loginPage.closeTheLoginDialogueBox();
//        try {
//            Thread.sleep(5000);
//        } catch (InterruptedException e) {
//            throw new RuntimeException(e);
//        }
//    }
//    @Test
//    public void closeLoginDialogueBox2(){
//        loginPage.closeTheLoginDialogueBox2();
//        try {
//            Thread.sleep(5000);
//        } catch (InterruptedException e) {
//            throw new RuntimeException(e);
//        }
//    }

    String username="pieahfkasnwr@gmail.com";
    String password="iuhfoisa@@!@#12";
    @Test
    public void VerificationForInvalidCase(){

        loginPage.enterUserName(username);
        loginPage.enterPassword(password);
        loginPage.clickLoginButton();
        loginPage.checkUsername();
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

    }



//    @Test
//    @Parameters({"username","password"})
//    public void checkLogin(String username,String password){
//        loginPage.enterUserName(username);
//        loginPage.enterPassword(password);
//        loginPage.clickLoginButton();
//        loginPage.checkLogin();
//        try {
//            Thread.sleep(5000);
//        } catch (InterruptedException e) {
//            throw new RuntimeException(e);
//        }
            @Test
            public void checkLogin(){

                String username="pieahfkasnwr@gmail.com";
                String password="iuhfoisa@@!@#12";
                loginPage.enterUserName(username);
                loginPage.enterPassword(password);
                loginPage.clickLoginButton();
                loginPage.checkLogin();
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }


                }
    @Test(dataProvider = "value")
    public void checkLogin2(String username , String password){

        loginPage.enterUserName(username);
        loginPage.enterPassword(password);
        loginPage.clickLoginButton();
        loginPage.checkLogin();
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    @Test(dataProvider = "value2")
    public void checkLogin3(String username , String password){

        loginPage.enterUserName(username);
        loginPage.enterPassword(password);
        loginPage.clickLoginButton();
        loginPage.checkLogin();
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
