package org.flipkart.com.tests;

import org.testng.annotations.Test;

public class NotificationPreferenceTest extends BaseTest{

    @Test
    public void openNotificationTab()
    {
        notificationPreferencePage.shiftWindowHandleDriver();
        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {

        }
    }
}
