package org.flipkart.com.pageobject;

import com.relevantcodes.extentreports.LogStatus;
import org.flipkart.com.wrapper.CustomDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import java.io.IOException;
import java.time.Duration;

public class AdsLoginPage extends CustomDriver {

    WebDriver driver;

    public AdsLoginPage(WebDriver webDriver)
    {
        this.driver=webDriver;
    }


    @FindBy(xpath = "//input[@placeholder='Enter email']")
    private WebElement enterUsername;

    @FindBy(xpath = "//input[@placeholder='Enter password']")
    private WebElement enterPassword;

    @FindBy(xpath = "//button[@type='submit']")
    private WebElement loginButton;

   @FindBy(xpath="//*[text()='Email field should not be empty']")
    private WebElement emailFieldEmpty;

    @FindBy(xpath="//*[text()='Password should not be empty']")
    private WebElement passwordFieldEmpty;

    @FindBy(xpath="//*[text()='Please enter a valid email']")
    private WebElement validEmail;


    @FindBy(xpath = "//*[text()='Account does not exist']")
    private WebElement noAccount;

    public boolean emailFieldIsEmptyOrNot()
    {
        return emailFieldEmpty.isDisplayed();
    }

    public boolean passwordFieldIsEmptyOrNot()
    {
        return passwordFieldEmpty.isDisplayed();
    }

    public boolean isEmailValidOrNot()
    {
        return validEmail.isDisplayed();
    }

    public boolean AccountPresentOrNot()
    {
        return noAccount.isDisplayed();
    }

    public void checkUsernameBoxEmpty()
    {
        driver.navigate().to("https://advertising.flipkart.com/login?returl=/?otracker=ch_vn_advertise_header");
        enterUsername.sendKeys("");
        enterPassword.sendKeys("Value1");
        try{
            Assert.assertTrue(emailFieldIsEmptyOrNot(),"Email is not Empty");
            extentTest.log(LogStatus.PASS,"Passed",extentTest.addScreenCapture(takeScreenShot()));
        }
        catch (Exception e)
        {
            System.out.println("Email is Not Empty");
            try {
                extentTest.log(LogStatus.FAIL,"Failed",extentTest.addScreenCapture(takeScreenShot()));
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }


    }
    public void checkPasswordBoxEmpty()
    {
        driver.navigate().to("https://advertising.flipkart.com/login?returl=/?otracker=ch_vn_advertise_header");
        enterUsername.sendKeys("value2@gmail.com");
        enterPassword.sendKeys("");
        loginButton.click();
            try{
                Assert.assertTrue(passwordFieldIsEmptyOrNot(),"Password is not Empty");
                extentTest.log(LogStatus.PASS,"Passed",extentTest.addScreenCapture(takeScreenShot()));
            }
            catch (Exception e)
                    {
                    System.out.println("password is Not Empty");
                        try {
                            extentTest.log(LogStatus.FAIL,"Failed",extentTest.addScreenCapture(takeScreenShot()));
                        } catch (IOException ex) {
                            throw new RuntimeException(ex);
                        }
                }


    }
    public void checkEmailNotCorrectFormat()
    {
        driver.navigate().to("https://advertising.flipkart.com/login?returl=/?otracker=ch_vn_advertise_header");
        enterUsername.sendKeys("value.com");
        enterPassword.sendKeys("");
        loginButton.click();
        try{
            Assert.assertTrue(isEmailValidOrNot(),"Email is correct format");
            extentTest.log(LogStatus.PASS,"Passed",extentTest.addScreenCapture(takeScreenShot()));
        }
        catch (Exception e)
        {
            System.out.println("Correct Format of Email");
            try {
                extentTest.log(LogStatus.FAIL,"Failed",extentTest.addScreenCapture(takeScreenShot()));
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }

    }
    public void checkEmailCorrectFormat()
    {
        driver.navigate().to("https://advertising.flipkart.com/login?returl=/?otracker=ch_vn_advertise_header");
        enterUsername.sendKeys("value2.com");
        enterPassword.sendKeys("");
        loginButton.click();
        try{
            Assert.assertTrue(isEmailValidOrNot(),"Email is not correct format");
            extentTest.log(LogStatus.PASS,"Passed",extentTest.addScreenCapture(takeScreenShot()));
        }
        catch (Exception e)
        {
            System.out.println("Not Correct Format of Email");
            try {
                extentTest.log(LogStatus.FAIL,"Failed",extentTest.addScreenCapture(takeScreenShot()));
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }

    }

}
