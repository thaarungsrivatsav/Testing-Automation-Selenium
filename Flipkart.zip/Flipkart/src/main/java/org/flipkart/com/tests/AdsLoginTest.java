package org.flipkart.com.tests;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class AdsLoginTest extends BaseTest{
    //methods inside @Test(we can give all these 6 steps)
    //1.groups will run first and then dependsongroups will get executed
    //2.dependOnMethods if we give in any test and give the another test name in that dependsOnMethods after that test is executed successfully this test will get executed
    //3.priority
    //4.enabled = false will skip that test or it will not execute that test
    //5.dependOnMethods , always = true is factor which will happen when dependOnMethods conditions failed also this parent test case will reun , if we dont five always true , it will throw error saying if one failure is arrived all other test cases won't execute
    //6.invocation count is the process in which the test cases will run repeatedly in a loop format

    @Test(groups = "smoke")//2
    public void checkUsernameBoxEmptyOrNot()
    {
        adsLoginPage.checkUsernameBoxEmpty();
        try {
            Thread.sleep(7000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    @Test(groups = "smoke")//3
    public void checkPasswordBoxEmptyOrNot()
    {
        adsLoginPage.checkPasswordBoxEmpty();
        try {
            Thread.sleep(8000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    @Test(invocationCount = 2 , invocationTimeOut = 1000008768 , timeOut = 160000)//4
    public void checkEmailNotCorrectFormat() {
        adsLoginPage.checkEmailNotCorrectFormat();
        try {
            Thread.sleep(8000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    @Test(dependsOnGroups = "smoke" )//5
    public void checkEmailCorrectFormat() {
        adsLoginPage.checkEmailCorrectFormat();
        try {
            Thread.sleep(8000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }



}
