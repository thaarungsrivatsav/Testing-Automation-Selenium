package org.flipkart.com.tests;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import jxl.Sheet;
import jxl.Workbook;
import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.DataFormatter;

import org.flipkart.com.pageobject.AdsLoginPage;
import org.flipkart.com.pageobject.HomePage;
import org.flipkart.com.pageobject.LoginPage;
import org.flipkart.com.pageobject.NotificationPreferencePage;
import org.openqa.selenium.MutableCapabilities;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import static jxl.Workbook.getWorkbook;

public class BaseTest {
    public static WebDriver driver;

    public static ExtentReports extentReports;

    public static ExtentTest extentTest;


    String browser = "chrome";

    HomePage homePage;
    LoginPage loginPage;

    AdsLoginPage adsLoginPage;

    NotificationPreferencePage notificationPreferencePage;

    @BeforeSuite//we added this method when we use extent report concept
    public void beforeSuite()
    {
        extentReports = new ExtentReports("C:\\Users\\gs1-thaaruns\\Desktop\\Testing\\Flipkart\\ExtentReports\\"+"report.html",true);
        extentReports.addSystemInfo("author","thaarun");
    }

    @BeforeMethod(alwaysRun = true)
    public void createDriver(ITestResult result , Method method)
    {

        if(browser.equalsIgnoreCase("chrome"))
        {
            System.setProperty( "webdirver.chrome.driver","C:\\Users\\gs1-thaaruns\\Desktop\\Testing\\Flipkart\\drivers\\chromedriver.exe");
          //driver = new ChromeDriver();
            String username = "kulandaiyan_WKaifA";
            String accessKey = "5sRiPRy2ws1wRX4zMRrs";
            String buildName = System.getenv("JENKINS_LABEL");

            MutableCapabilities capabilities = new MutableCapabilities();
            capabilities.setCapability("browserName", "Chrome");
            capabilities.setCapability("browserVersion", "100.0");
            HashMap<String, Object> browserstackOptions = new HashMap<String, Object>();
            browserstackOptions.put("os", "Windows");
            browserstackOptions.put("osVersion", "10");
            browserstackOptions.put("sessionName", "BStack Build Name: " + buildName);
            browserstackOptions.put("seleniumVersion", "4.0.0");
            capabilities.setCapability("bstack:options", browserstackOptions);

            try {
                driver = new RemoteWebDriver(new URL("https://" + username + ":" + accessKey + "@hub.browserstack.com/wd/hub"), capabilities);
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            }
            capabilities = new MutableCapabilities();
            capabilities.setCapability("browserName", "Chrome");
            capabilities.setCapability("browserVersion", "100.0");
            browserstackOptions = new HashMap<String, Object>();
            browserstackOptions.put("os", "Windows");
            browserstackOptions.put("osVersion", "10");
            browserstackOptions.put("sessionName", "BStack Build Name: " + buildName);
            browserstackOptions.put("seleniumVersion", "4.0.0");
            capabilities.setCapability("bstack:options", browserstackOptions);

            try {
                 driver = new RemoteWebDriver(new URL("https://" + username + ":" + accessKey + "@hub.browserstack.com/wd/hub"), capabilities);
            } catch (MalformedURLException e) {
                throw new RuntimeException(e);
            }
        }
        else if(browser.equalsIgnoreCase("firefox"))
        {
            System.setProperty( "webdirver.chrome.driver","C:\\Users\\gs1-thaaruns\\Desktop\\Testing\\Flipkart\\drivers\\chromedriver.exe");
            driver = new FirefoxDriver();
        }
        driver.get("https://www.flipkart.com/");
        //driver.get("https://advertising.flipkart.com/login?returl=/?otracker=ch_vn_advertise_header");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
        homePage = new HomePage(driver);
//        loginPage = new LoginPage(driver);
        loginPage = PageFactory.initElements(driver,LoginPage.class);
        adsLoginPage = PageFactory.initElements(driver,AdsLoginPage.class);
        notificationPreferencePage = PageFactory.initElements(driver,NotificationPreferencePage.class);
       //extentTest = extentReports.startTest(result.getClass().getName());
        extentTest = extentReports.startTest(method.getName());
    }


    @AfterMethod(alwaysRun = true)
    public void closeBrowser()
    {

        driver.quit();
        extentReports.endTest(extentTest);
    }
    @AfterSuite//we added this method when we use extent report concept
    public void close()
    {
        extentReports.flush();
    }


    ///this is data provider concept where we send the values as objects and pass it in internal file
    @DataProvider(name = "value")
    public Object[][] values()
    {
        return new Object[][]{{"value1.gmail.com","Password@42342#$"},{"ksadhfds2@gmail.com","password@5231#$"}};
    }

    //fetching the data from excel sheet and passing at as object of strings to the test method
    //excel related code starts here
    //this function will fetch the data from the excel sheet
    public String[][] getExcelData(String fileName, String sheetName) throws Exception{
        String[][] arrayExcelData = null;
        try {
            FileInputStream fs = new FileInputStream(fileName);
            Workbook wb = getWorkbook(fs);
            Sheet sh = wb.getSheet(sheetName);

            int totalNoOfCols = sh.getColumns();
            int totalNoOfRows = sh.getRows();

            arrayExcelData = new String[totalNoOfRows-1][totalNoOfCols];

            for (int i= 1 ; i < totalNoOfRows; i++) {

                for (int j=0; j < totalNoOfCols; j++) {
                    arrayExcelData[i-1][j] = sh.getCell(j, i).getContents();
                }

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
            e.printStackTrace();
        }
        return arrayExcelData;
    }

    //this will pass and store the data provider value into this function and pass it to the test function
    @DataProvider(name="value2")
    public Object[][] loginData() throws Exception {
        Object[][] arrayObject = getExcelData("C:\\Users\\gs1-thaaruns\\Desktop\\Testing\\Flipkart\\Excel Sheet for Testing\\LoginSheet.xls","Sheet1");
        return arrayObject;
    }
    //excel related code ends
}
