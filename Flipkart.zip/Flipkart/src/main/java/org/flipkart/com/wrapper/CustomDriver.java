package org.flipkart.com.wrapper;

import org.apache.commons.io.FileUtils;
import org.flipkart.com.tests.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.io.File;
import java.io.IOException;
import java.util.Random;

public class CustomDriver extends BaseTest {

    public void clickByXPath(String xPath){
        driver.findElement(By.xpath(xPath)).click();
    }
    public void enterByXPath(String xPath,String text){
        driver.findElement(By.xpath(xPath)).sendKeys(text);
    }
    public String takeScreenShot() throws IOException {
        TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
        File screenshot = takesScreenshot.getScreenshotAs(OutputType.FILE);
        String name = "screenshot";
        Random random = new Random();
        int randomValue= random.nextInt(1000);
        String path =  "C:\\Users\\gs1-thaaruns\\Desktop\\Testing\\Flipkart\\Screenshot\\"+randomValue+".png";
        FileUtils.copyFile(screenshot, new File(path));
        return path;
    }

}
