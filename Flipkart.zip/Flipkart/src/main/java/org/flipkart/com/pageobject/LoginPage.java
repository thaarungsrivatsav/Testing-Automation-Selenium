package org.flipkart.com.pageobject;
import com.relevantcodes.extentreports.LogStatus;
import org.flipkart.com.wrapper.CustomDriver;
import org.omg.CORBA.PRIVATE_MEMBER;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import java.io.IOException;

import static org.flipkart.com.tests.BaseTest.extentTest;

public class LoginPage extends CustomDriver {

    WebDriver driver;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    @FindBy(xpath = "//button[text()='✕']")
    private WebElement login_closeButton;
    String xpathForButton = "//button[text()='✕']";


    @FindBy(xpath = "//form[@autocomplete]//input[@type='text']")
    private WebElement enterUserName;

    @FindBy(xpath = "//form[@autocomplete]//input[@type='password']")
    private WebElement enterPassword;

    @FindBy(xpath = "//form[@autocomplete]//button[@type='submit']")
    private WebElement clickLoginButton;

    @FindBy(xpath = "//*[text()='Please enter valid Email ID/Mobile number']")
    private WebElement notALoginUser;

    @FindBy(xpath = "//*[text()='CONTINUE']")
    private WebElement newUser;


    public void closeTheLoginDialogueBox() {
        login_closeButton.click();
    }
    public void closeTheLoginDialogueBox2() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", driver.findElement(By.xpath("//a[text()='Login']")));
    }

    public void clickLoginButton(){
        clickLoginButton.click();
    }
    public void enterUserName(String username){
        enterUserName.sendKeys(username);
    }

    public void enterPassword(String password){
        enterPassword.sendKeys(password);
    }

    public boolean verifyLoginStatus(){
        return notALoginUser.isDisplayed();
    }

    public boolean newUserCreated(){
        return newUser.isDisplayed();
    }

    public void checkLogin()
    {
        try{
            Assert.assertTrue(newUserCreated(),"Validation Success");
            extentTest.log(LogStatus.PASS,"Test Case is Passed in Login Check",extentTest.addScreenCapture(takeScreenShot()));
        }
        catch(Exception e) {
            try {
                extentTest.log(LogStatus.FAIL,"Test Case is Failed in Login Check",extentTest.addScreenCapture(takeScreenShot()));
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }

    }
    public void checkUsername()
    {
        try{
            Assert.assertTrue(verifyLoginStatus(),"Validation Success");
            extentTest.log(LogStatus.PASS,"Given User Name is valid",extentTest.addScreenCapture(takeScreenShot()));

        }
        catch(Exception e) {
            try {
                extentTest.log(LogStatus.FAIL,"Given User Name is not Valid",extentTest.addScreenCapture(takeScreenShot()));
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        }

    }


}