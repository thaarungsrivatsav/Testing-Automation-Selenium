package org.flipkart.com.pageobject;

import org.flipkart.com.wrapper.CustomDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import java.time.Duration;
import java.util.Set;

public class NotificationPreferencePage extends CustomDriver {

    WebDriver driver;

    public NotificationPreferencePage(WebDriver webDriver)
    {
        this.driver = webDriver;
    }

    public void shiftWindowHandleDriver()
    {
        driver.findElement(By.xpath("//*[text()='✕']")).click();
        driver.manage().timeouts().scriptTimeout(Duration.ofSeconds(10));
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(By.xpath("//*[text()='More']"))).click().build().perform();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();",driver.findElement(By.xpath("//*[text()='Notification Preferences']")));
        driver.findElement(By.xpath("//a[text()='Login']")).click();
        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
