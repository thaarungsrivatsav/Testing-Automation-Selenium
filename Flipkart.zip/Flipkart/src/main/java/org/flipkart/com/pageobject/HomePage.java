package org.flipkart.com.pageobject;

import org.flipkart.com.wrapper.CustomDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import java.time.Duration;

public class HomePage extends CustomDriver {

    WebDriver driver;

    public HomePage(WebDriver webDriver)
    {
        this.driver=webDriver;
    }

    public void checkLoginFormIsDisplayed()
    {
        System.out.println(driver.findElement(By.xpath("//*[@class='_3wFoIb row']")).isDisplayed());
    }

    public void clickOnMoreUsingActionsHover()
    {
        driver.findElement(By.xpath("//*[text()='✕']")).click();
        driver.manage().timeouts().scriptTimeout(Duration.ofSeconds(10));
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(By.xpath("//*[text()='More']"))).click().build().perform();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();",driver.findElement(By.xpath("//*[text()='Advertise']")));
    }

}
