package org.flipkart.com.tests;

import org.testng.annotations.Test;

public class HomePageTest extends BaseTest{

    @Test
    public void checkLoginForm()
    {
        homePage.checkLoginFormIsDisplayed();
    }

    @Test
    public void clickMore()
    {
        homePage.clickOnMoreUsingActionsHover();
        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
