package com.mainfiles.pageobjects;

import com.mainfiles.wrapper.CustomDriver;
import org.checkerframework.checker.units.qual.C;
import org.openqa.selenium.WebDriver;

public class ContactUs extends CustomDriver {


    WebDriver webDriver;

    String enterNameXpath = "//*[@id='username']";

    String enterPasswordXpath = "//*[@id='password']";

    String clickLoginXpath = "//*[@id='Login']";

    public void enterName()
    {

        enterByXPath(enterNameXpath,"dataSendingFromEnterName");
    }

    public void enterPassword()
    {
        enterByXPath(enterPasswordXpath,"dataSendingFromEnterPassword");
    }

    public void clickLogin()
    {
        clickByXPath(clickLoginXpath);
    }

    public ContactUs(WebDriver webDriver)
    {
        this.webDriver = webDriver;
    }
}
