package com.mainfiles;

public class ConstructorClass {

    public ConstructorClass(){
        System.out.println("Constructor Called");
    }

    void display()
    {
        System.out.println("Method Called");
    }
}
