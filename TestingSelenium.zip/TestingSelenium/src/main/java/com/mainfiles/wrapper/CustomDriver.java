package com.mainfiles.wrapper;
import com.mainfiles.tests.BaseTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CustomDriver extends BaseTest {

    public void clickByXPath(String xPath){
        webDriver.findElement(By.xpath(xPath)).click();
    }
    public void enterByXPath(String xPath,String text){
        webDriver.findElement(By.xpath(xPath)).sendKeys(text);
    }

}
