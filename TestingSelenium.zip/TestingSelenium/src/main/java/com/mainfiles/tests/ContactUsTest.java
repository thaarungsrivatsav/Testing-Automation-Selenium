package com.mainfiles.tests;

import com.mainfiles.pageobjects.ContactUs;
import org.apache.commons.io.FileUtils;
//import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;
import java.util.Random;

public class ContactUsTest extends BaseTest{

    @Test
    public void checkLogin()
    {
//        webDriver = createDriver();
        ContactUs obj = new ContactUs(webDriver);
        obj.enterName();
        obj.enterPassword();
        obj.clickLogin();
       // webDriver.findElement(By.id("username")).sendKeys("data");//this will work
        // webDriver.findElement(By.id("password")).sendKeys("data");//this will work
        System.out.println(webDriver.findElement(By.id("username")).getAttribute("value"));
      //  webDriver.findElement(By.xpath("//*[@id='Login']")).click();//this will work
//        try {
//            takeScreenShot();
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
        if((webDriver.findElement(By.id("error")).isDisplayed()))
        {
            System.out.println("Wrong Credentials is given");
        }
        else{
            System.out.println("True values");
        }
    }
//    @Test
    @Test
    public void checkClear()
    {
//        webDriver = createDriver();
        System.out.println("After Login Clicked: "+ webDriver.findElement(By.id("username")).getAttribute("value").getClass());

    }
    public void takeScreenShot() throws IOException {
        TakesScreenshot takesScreenshot = (TakesScreenshot) webDriver;
        File screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
        String name = "Screenshot";
        Random r = new Random();
        int number = r.nextInt(1000);
        name = name + String.valueOf(number);
        FileUtils.copyFile(screenshot, new File("C:\\Users\\gs1-thaaruns\\Desktop\\Testing\\Screenshots\\"+name+".png"));

    }
}
