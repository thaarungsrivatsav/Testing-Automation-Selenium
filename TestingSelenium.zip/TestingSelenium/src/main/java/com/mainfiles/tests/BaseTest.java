package com.mainfiles.tests;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class BaseTest {
    public static WebDriver webDriver;
//@AfterEach , @BeforeEach , @Test in junit testing we use
//@BeforeTest , @AfterTest , @Test we use in testNg dependencies -> more annotations are @BeforeClass , @AfterClass , @BeforeSuite , @AfterSuite
    @BeforeTest
    public void createDriver()
    {

        System.setProperty( "webdirver.chrome.driver","C:\\Users\\gs1-thaaruns\\Desktop\\Testing\\TestingSelenium\\src\\main\\java\\drivers\\chromedriver.exe");
        webDriver = new ChromeDriver();
        webDriver.get("https://login.salesforce.com/?locale=in");
        webDriver.manage().window().maximize();
    }


    @AfterTest
    public void closeBrowser()
    {
        webDriver.quit();
    }
}
