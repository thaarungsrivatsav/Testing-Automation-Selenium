package com.mainfiles.tests;

public class RecentPost extends BaseTest{
    public void method1()
    {
        System.out.println();
    }
    public void method2()
    {
        System.out.println();
    }
}
