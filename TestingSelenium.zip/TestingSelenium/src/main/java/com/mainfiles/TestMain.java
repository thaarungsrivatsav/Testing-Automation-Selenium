package com.mainfiles;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;




public class TestMain {
    public void TestMain() {
        ConstructorClass c = new ConstructorClass();
        c.display();
        DriverClass d = new DriverClass();

//        webDriver.manage().window().fullscreen();
//       WebElement l = webDriver.findElement(By.id("forgot_password_link"));
//        l.click();
//        webDriver.navigate().back();

//       webDriver.findElement(By.className("input r4 wide mb16 mt8 password")).sendKeys("Dataaaa");

//    webDriver.findElement(By.tagName("a")).click(); correct syntax , but wont work multiple anchors are there , so it won't identify
//        webDriver.findElement(By.linkText("Use Custom Domain")).click(); //this will work
//        webDriver.findElement(By.partialLinkText("Forgot")).click(); //this will work
//        webDriver.findElement(By.xpath("//*[text()='Try for Free']")).click(); //this will work
//        webDriver.findElement(By.xpath("//*[@id='signup_link']")).click();//this will work


    }
}