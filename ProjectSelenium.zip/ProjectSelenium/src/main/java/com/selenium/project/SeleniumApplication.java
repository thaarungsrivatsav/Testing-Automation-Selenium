package com.selenium.project;
//
//import org.apache.commons.io.FileUtils;
//import org.junit.jupiter.api.AfterEach;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.openqa.selenium.By;
//import org.openqa.selenium.OutputType;
//import org.openqa.selenium.TakesScreenshot;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.apache.commons.*;
//import java.io.File;
//import java.io.IOException;
//import java.util.Objects;
//import java.util.Random;
//
public class SeleniumApplication {
//
//
//    ChromeDriver driver;
//
//    @BeforeEach
//    public void browser() {
//        System.setProperty("webdriver.chrome.driver", "C:\\Users\\gs1-kulandaiyans\\Documents\\Docs\\selenium\\ProjectSelenium\\drivers\\chromedriver.exe");
//        driver = new ChromeDriver();
//        driver.get("http://www.seleniumframework.com/practiceform/");
//    }
//
//    @Test
//    void submit() throws IOException {
//        driver.findElement(By.xpath("//*[contains(@class, 'validate[required]')]")).sendKeys("Amala");
//        driver.findElement(By.xpath("//*[contains(@class, 'validate[required,custom[email]]')]")).sendKeys("amal@gmail.com");
//        driver.findElement(By.xpath("//*[contains(@class, 'validate[required,custom[phone]]')]")).sendKeys("1234567890");
//        driver.findElement(By.xpath("//*[@name='country']")).sendKeys("India");
//        driver.findElement(By.xpath("//*[@name='company']")).sendKeys("Expeditors GSC");
//        driver.findElement(By.xpath("//*[@name='message']")).sendKeys("Welcome Home");
//        driver.findElement(By.xpath("//*[text()='Submit']")).click();
//        takeScreenShot();
//    }
//
//    @Test
//    void clear() throws IOException {
//        driver.findElement(By.xpath("//*[contains(@class, 'validate[required]')]")).sendKeys("Amala");
//        driver.findElement(By.xpath("//*[contains(@class, 'validate[required,custom[email]]')]")).sendKeys("amal@gmail.com");
//        driver.findElement(By.xpath("//*[contains(@class, 'validate[required,custom[phone]]')]")).sendKeys("1234567890");
//        driver.findElement(By.xpath("//*[@name='country']")).sendKeys("India");
//        driver.findElement(By.xpath("//*[@name='company']")).sendKeys("Expeditors GSC");
//        driver.findElement(By.xpath("//*[@name='message']")).sendKeys("Welcome Home");
//        driver.findElement(By.xpath("//*[contains(@class,'clear-form')]")).click();
//        checkClear();
//        takeScreenShot();
//    }
//
//    void checkClear() {
//        String a, b, c, d, e, f;
//        a = driver.findElement(By.xpath("//*[contains(@class, 'validate[required]')]")).getAttribute("value");
//        b = driver.findElement(By.xpath("//*[contains(@class, 'validate[required,custom[email]]')]")).getAttribute("value");
//        c = driver.findElement(By.xpath("//*[contains(@class, 'validate[required,custom[phone]]')]")).getAttribute("value");
//        d = driver.findElement(By.xpath("//*[@name='country']")).getAttribute("value");
//        e = driver.findElement(By.xpath("//*[@name='company']")).getAttribute("value");
//        f = driver.findElement(By.xpath("//*[@name='message']")).getAttribute("value");
//
//        if (Objects.equals(a, "") && Objects.equals(b, "") && Objects.equals(c, "") &&
//                Objects.equals(d, "") && Objects.equals(e, "") && Objects.equals(f, "")) {
//            System.out.println("Form is working properly");
//        } else {
//            System.out.println(a + "\n" + b + "\n" + c + "\n" + d + "\n" + e + "\n" + f);
//        }
//
//    }
//    @AfterEach
//    void closeBrowser(){
//        driver.quit();
//    }
//
//    void takeScreenShot() throws IOException {
//        TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
//        File screenshot = takesScreenshot.getScreenshotAs(OutputType.FILE);
//        String name = "screenshot";
//        Random random = new Random();
//        int randomValue= random.nextInt(1000);
//        FileUtils.copyFile(screenshot, new File("C:\\Project Screenshots\\"+randomValue+".png"));
//    }
//
//}
//
////    public static void main(String[] args) throws InterruptedException {
////        System.setProperty("webdriver.chrome.driver","C:\\Users\\gs1-kulandaiyans\\Documents\\Docs\\selenium\\ProjectSelenium\\drivers\\chromedriver.exe");
////
////
//////        driver.findElement(By.id("signup")).click();
//////        driver.findElement(By.className("label")).sendKeys("kulandaiyan");
//////        driver.findElement(By.id("password")).sendKeys(("kulandaiyan"));
//////        driver.findElement(By.tagName("p")).click();
//////        driver.findElement(By.linkText("Forgot Your Password?")).click();
//////        driver.findElement(By.partialLinkText("Forgot Your")).click();
//////        driver.findElement(By.xpath("//*[@id='signup_link']")).click();
////    }
}
