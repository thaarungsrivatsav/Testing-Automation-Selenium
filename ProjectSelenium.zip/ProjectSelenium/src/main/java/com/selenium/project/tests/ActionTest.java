package com.selenium.project.tests;

import org.testng.annotations.Test;

public class ActionTest extends BaseTest{

    @Test
    public void verify()
    {
        actionMethods.verifyActions();
        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    @Test
    public void verifyDragAndDrop()
    {
        actionMethods.dragAndDrop();
        try {
            Thread.sleep(9000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
