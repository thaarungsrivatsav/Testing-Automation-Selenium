package com.selenium.project.tests;

import org.testng.annotations.Test;

public class AlertWindowTest extends BaseTest{

    @Test
    public void verifyAlert()
    {
        alertWindow.practiceAlert();
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void verifyConfirmBox()
    {
        alertWindow.practiceConfirmBox();
        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    @Test
    public void verifyPromptBox()
    {
        alertWindow.practicePromptBox();
        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    @Test
    public void verifyGetTextBox()
    {
        alertWindow.practiceGetValueFromBox();
        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
