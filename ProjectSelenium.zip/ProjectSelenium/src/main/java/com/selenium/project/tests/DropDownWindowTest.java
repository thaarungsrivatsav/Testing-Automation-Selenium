package com.selenium.project.tests;

import org.testng.annotations.Test;

public class DropDownWindowTest extends BaseTest{

    @Test
    public void dropDown()
    {
        dropDownWindow.checkDropdown();
        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
