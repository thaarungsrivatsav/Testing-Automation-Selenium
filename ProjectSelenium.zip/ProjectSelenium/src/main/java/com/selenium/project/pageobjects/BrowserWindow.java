package com.selenium.project.pageobjects;

import com.selenium.project.wrapper.CustomDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.Set;

public class BrowserWindow extends CustomDriver {

    WebDriver driver;

    public BrowserWindow(WebDriver webDriver) {
        this.driver = webDriver;
    }

    public void HandleNewBrowserWindow() {

        clickByXPath("//button[text()='New Browser Window']");
    }

    public void handleMultipleWindows(String parentWindow,String title){
        Set<String> handles =  driver.getWindowHandles();
        for(String windowHandle  : handles)
        {
            driver.switchTo().window(windowHandle);
            if(driver.getTitle().equals(title)) {
                driver.manage().window().maximize();
                driver.findElement(By.xpath("//*[text()='Choosing an Automation Solution']")).click();
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
                driver.close(); //closing child window
                driver.switchTo().window(parentWindow); //cntrl to parent window
//                break;
            }
        }

    }

    public void frameChanging(){
//        clickByXPath("//*[@Id='Click']");
        String frame="//iframe[@src='default.html']";
        WebElement webElement = driver.findElement(By.xpath(frame));
        driver.switchTo().frame(webElement);
        clickMeInsideFrame();
    }

    public void clickMeInsideFrame()
    {
        clickByXPath("//*[@Id='Click']");
    }

    public void frameChangingToFrame()
    {
        driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@src=\"page.html\"]")));
        driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@src=\"nested.html\"]")));
        driver.findElement(By.xpath( "//button[@Id='Click1']")).click();
    }




}
