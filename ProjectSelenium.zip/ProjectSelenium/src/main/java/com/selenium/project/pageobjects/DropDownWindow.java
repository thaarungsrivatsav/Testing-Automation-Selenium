package com.selenium.project.pageobjects;

import com.selenium.project.wrapper.CustomDriver;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class DropDownWindow extends CustomDriver {
    WebDriver driver;

    public DropDownWindow(WebDriver driver)
    {
        this.driver = driver;
    }

    public void checkDropdown()
    {
        driver.navigate().to("http://testleaf.herokuapp.com/pages/Dropdown.html");
        WebElement dropDown = driver.findElement(By.xpath("//*[@id='dropdown1']"));
        Select selectDropdown = new Select(dropDown);
        selectDropdown.selectByIndex(0);

        WebElement dropDown2 = driver.findElement(By.xpath("//*[contains(@name,'dropdown2')]"));
        Select selectDropdown2 = new Select(dropDown2);
        selectDropdown2.selectByValue("0");

        WebElement dropDown3 = driver.findElement(By.xpath("//*[@id='dropdown3']"));
        Select selectDropdown3 = new Select(dropDown3);
        selectDropdown3.selectByVisibleText("Loadrunner");



        WebElement dropDown4 = driver.findElement(By.xpath("//select[@multiple]"));
        Select selectDropdown4 = new Select(dropDown4);
        selectDropdown4.selectByValue("1");
        selectDropdown4.selectByValue("2");
        selectDropdown4.deselectAll();//this will deselect all the above selected options

        System.out.println("Size of dropdown 3 is printed: "+selectDropdown3.getOptions().size());


    }
}
