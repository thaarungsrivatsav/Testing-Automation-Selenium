package com.selenium.project.tests;

import org.openqa.selenium.By;

import org.testng.annotations.Test;

import java.io.IOException;

import java.util.Objects;

public class ContactTest extends BaseTest{


    @Test
    void submit(){
        contactUs.enterName("Mani");
        contactUs.enterEmail("mani123@gmail.com");
        contactUs.enterCountryName("South Africa");
        contactUs.enterPhoneNumber("8428566196");
        contactUs.enterCompanyName("Larsen & Touron Info tech");
        contactUs.enterMessage("Welcome to LTI");
        contactUs.submit();
    }


    @Test
    void clear() throws IOException {
        contactUs.enterNameByClassAttribute("Naveen");
        contactUs.enterEmailByClassAttribute("naveen12prasad@yaboo.com");
        contactUs.enterPhoneNumberByClassAttribute("7550171344");
        contactUs.submitUsingLinkTextAttribute();
        checkClear();
    }


    void checkClear() {
        String a, b, c, d, e, f;
        a = driver.findElement(By.xpath("//*[contains(@class, 'validate[required]')]")).getAttribute("value");
        b = driver.findElement(By.xpath("//*[contains(@class, 'validate[required,custom[email]]')]")).getAttribute("value");
        c = driver.findElement(By.xpath("//*[contains(@class, 'validate[required,custom[phone]]')]")).getAttribute("value");
        d = driver.findElement(By.xpath("//*[@name='country']")).getAttribute("value");
        e = driver.findElement(By.xpath("//*[@name='company']")).getAttribute("value");
        f = driver.findElement(By.xpath("//*[@name='message']")).getAttribute("value");

        if (Objects.equals(a, "") && Objects.equals(b, "") && Objects.equals(c, "") &&
                Objects.equals(d, "") && Objects.equals(e, "") && Objects.equals(f, "")) {
            System.out.println("Form is Cleared ");
        } else {
            System.out.println(a + "\n" + b + "\n" + c + "\n" + d + "\n" + e + "\n" + f);
        }

    }

    @Test
    void verifyClearValues()
    {
        contactUs.enterNameByClassAttribute("Naveen");
       contactUs.clearUsingLinkTextAttribute();
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        contactUs.verifyUsingWait();
    }

    @Test
    void verifyClearValues2()
    {
        contactUs.enterNameByClassAttribute("Naveen");
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        contactUs.clearUsingLinkTextAttribute();
        contactUs.verifyUsingFluentWait();
    }
}
