package com.selenium.project.wrapper;

import com.selenium.project.tests.BaseTest;
import org.openqa.selenium.By;


public class CustomDriver extends BaseTest {


    public void clickByXPath(String xpath){
        driver.findElement(By.xpath(xpath)).click();
    }

    public void enterByXPath(String xpath, String test){
        driver.findElement(By.xpath(xpath)).sendKeys(test);
    }

    public void clickByLinkText(String valueOfClass){
        driver.findElement(By.linkText(valueOfClass)).click();
    }

    public void enterByClass(String classValue,String test){
        driver.findElement(By.className(classValue)).sendKeys(test);
    }

//    public void enterByText(String textValue,String text){
//        driver.findElement(By.linkText()).sendKeys(text);
//    }
    //tcipxcn

//    public void enterByPartialText(String textValue, String text){
//        driver.findElement(By.partialLinkText()).sendKeys(text);
//    }
    

//    void takeScreenShot() throws IOException {
//        TakesScreenshot takesScreenshot = (TakesScreenshot) driver;
//        File screenshot = takesScreenshot.getScreenshotAs(OutputType.FILE);
//        String name = "screenshot";
//        Random random = new Random();
//        int randomValue= random.nextInt(1000);
//        FileUtils.copyFile(screenshot, new File("C:\\Project Screenshots\\"+randomValue+".png"));
//    }
}
