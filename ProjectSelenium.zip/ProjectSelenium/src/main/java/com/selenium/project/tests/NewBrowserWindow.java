package com.selenium.project.tests;


import org.openqa.selenium.By;
import org.testng.annotations.Test;

import java.util.Set;

public class NewBrowserWindow extends BaseTest{

    @Test
    void clickNewBrowserWindowButton()
    {
        browserWindow.HandleNewBrowserWindow();
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void clickNewBrowserWindowButtonAndClickAnotherButton()
    {

        browserWindow.HandleNewBrowserWindow();
        String parentWindow = driver.getWindowHandle();
        String title = "Selenium Framework | Selenium, Cucumber, Ruby, Java et al.";
        browserWindow.handleMultipleWindows(parentWindow,title);
    }

    @Test
    void newWindow()
    {
        browserWindow.frameChanging();
        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void newWindow1()
    {
        browserWindow.frameChangingToFrame();
        try {
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }



}
