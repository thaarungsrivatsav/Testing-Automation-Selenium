package com.selenium.project.pageobjects;

import com.selenium.project.wrapper.CustomDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.List;

public class RecentPost extends CustomDriver {
    WebDriver driver ;
//    private static final String recentPostItems="//*[contains(@Id,'recent-posts')]//a";
    private static final String recentPostItems="//button";
    public RecentPost(WebDriver driver){
        this.driver=driver;
    }
    public void recentPostList(){
        List<WebElement> recentPosts=driver.findElements(By.xpath(recentPostItems));
        //System.out.println(recentPosts);
        for (WebElement rp : recentPosts){
         System.out.println(rp.getText());
         }
    }

}
