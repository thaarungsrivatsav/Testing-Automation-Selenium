package com.selenium.project.tests;


import org.testng.annotations.Test;

public class RecentPostTest extends BaseTest{


    @Test
    public void display(){
        recentPost.recentPostList();
    }
}