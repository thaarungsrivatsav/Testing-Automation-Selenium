package com.selenium.project.pageobjects;

import com.selenium.project.wrapper.CustomDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ContactUs extends CustomDriver{

    WebDriver driver;

    public String numberXpath,nameXpath,countryNameXpath,companyNameXpath,messageXpath,submitXpath;

    String emailXpath="//*[contains(@class, 'validate[required]')]";


    public ContactUs(WebDriver webDriver)
    {
        this.driver=webDriver;
    }

    public void enterName(String name){
        enterByXPath("//*[contains(@class, 'validate[required]')]",name);
    }


    public void enterEmail(String email){
        enterByXPath("//*[contains(@class, 'validate[required,custom[email]]')]",email);
    }

    public void enterPhoneNumber(String mobileNumber){
        enterByXPath("//*[contains(@class, 'validate[required,custom[phone]]')]",mobileNumber);
    }

    public void enterCountryName(String countryName){
        enterByXPath("//*[@name='country']",countryName);
    }


    public void enterCompanyName(String companyName){
        enterByXPath("//*[@name='company']",companyName);
    }

    public void enterMessage(String message){
        enterByXPath("//*[@name='message']",message);
    }

    public void submit(){
        clickByXPath("//*[text()='Submit']");
    }

    public void submitUsingLinkTextAttribute(){
        clickByLinkText("Submit");
    }
    public void clearUsingLinkTextAttribute(){
        clickByLinkText("clear");
    }

    public void enterNameByClassAttribute(String name){
        enterByClass("validate[required]",name);
    }


    public void enterEmailByClassAttribute(String email){
        enterByClass("validate[required,custom[email]]",email);

    }

    public void enterPhoneNumberByClassAttribute(String mobileNumber){
        enterByClass("validate[required,custom[phone]]",mobileNumber);
    }

    public void enterCountryNameByClassAttribute(String countryName){
        enterByClass("form-country",countryName);
    }


    public void enterCompanyNameByClassAttribute(String companyName){
            enterByClass("form-company",companyName);
    }

    public void enterMessageByClassAttribute(String message){
        enterByClass("form-message",message);
    }


    public void enterCountryNameByText(String text){

    }
    public void verifyUsingWait()
    {
        Duration time = Duration.ofSeconds(20);
        WebDriverWait wait =  new WebDriverWait(driver ,time);

        try{
            wait.until(ExpectedConditions.attributeContains(By.xpath("//*[contains(@class, 'validate[required]')]"),"value","Naveen"));
            System.out.println("True");
        }
        catch(Exception e)
        {
            System.out.println("false no name is present");
        }
    }

    public void verifyUsingFluentWait()
    {
        FluentWait fluentWait = new FluentWait<>(driver);
        fluentWait.withTimeout(Duration.ofSeconds(30));
        fluentWait.pollingEvery(Duration.ofSeconds(5));
        fluentWait.ignoring(Exception.class);
        try{
            fluentWait.until(ExpectedConditions.attributeContains(By.xpath("//*[contains(@class, 'validate[required]')]"),"value","guna"));
            System.out.println("True");
        }
        catch (Exception e)
        {
            System.out.println("False in fluent wait");
        }

    }

}
