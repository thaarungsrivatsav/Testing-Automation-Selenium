package com.selenium.project.pageobjects;

import com.selenium.project.wrapper.CustomDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class ActionMethods extends CustomDriver {

    WebDriver webDriver;

    public ActionMethods(WebDriver driver)
    {
        this.webDriver=driver;
    }

    public void verifyActions()
    {
        driver.navigate().to("http://testleaf.herokuapp.com/");
        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(By.xpath("//*[text()='Window']"))).click().build().perform();
    }

    public void dragAndDrop() {
        driver.get("http://demo.guru99.com/test/drag_drop.html");

        WebElement From=driver.findElement(By.xpath("//*[@id='credit2']/a"));

        WebElement To=driver.findElement(By.xpath("//*[@id='bank']/li"));

        Actions act=new Actions(driver);

        act.dragAndDrop(From, To).build().perform();
    }
}
