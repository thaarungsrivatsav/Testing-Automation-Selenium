package com.selenium.project.pageobjects;

import com.selenium.project.wrapper.CustomDriver;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AlertWindow extends CustomDriver {
    WebDriver driver;
    public AlertWindow(WebDriver driver)
    {
        this.driver=driver;
    }

    public void practiceAlert()
    {
            driver.navigate().to("http://testleaf.herokuapp.com/pages/Alert.html");
            driver.findElement(By.xpath("//*[text()='Alert Box']")).click();
    }

    public void practiceConfirmBox()
    {
        driver.navigate().to("http://testleaf.herokuapp.com/pages/Alert.html");
        driver.findElement(By.xpath("//*[text()='Confirm Box']")).click();
        Alert a = driver.switchTo().alert();
        a.accept();
    }

    public void practicePromptBox()
    {
        driver.navigate().to("http://testleaf.herokuapp.com/pages/Alert.html");
        driver.findElement(By.xpath("//*[text()='Prompt Box']")).click();
        Alert a = driver.switchTo().alert();
        a.sendKeys("Hi , boss");
        a.accept();
    }
    public void practiceGetValueFromBox()
    {
        driver.navigate().to("http://testleaf.herokuapp.com/pages/Alert.html");
        driver.findElement(By.xpath("//*[text()='Line Breaks?']")).click();
        Alert a = driver.switchTo().alert();
        System.out.println(a.getText());
        a.accept();

    }

}
