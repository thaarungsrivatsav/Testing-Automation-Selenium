package com.selenium.project.tests;

import com.selenium.project.pageobjects.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;


public class BaseTest {

    public static WebDriver driver;
    public static ContactUs contactUs;

    public static RecentPost recentPost;

    public static BrowserWindow browserWindow;

    public static AlertWindow alertWindow;

    public static DropDownWindow dropDownWindow;

    public static ActionMethods actionMethods;

    @BeforeTest
    public void browser() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\gs1-thaaruns\\Desktop\\Testing\\ProjectSelenium\\drivers\\chromedriver.exe");
       // this.driver = new HtmlUnitDriver();
        this.driver = new ChromeDriver();
        this.driver.get("http://www.seleniumframework.com/practiceform/"); //for form practices this link and navigation to other window , browser window test cases this url

     //  this.driver.get("http://testleaf.herokuapp.com/pages/frame.html"); // frames and nested frames accessing methods url
        driver.manage().window().maximize();
        contactUs = new ContactUs(driver);
        recentPost = new RecentPost(driver);
        browserWindow = new BrowserWindow(driver);
        alertWindow = new AlertWindow(driver);
        dropDownWindow = new DropDownWindow(driver);
        actionMethods = new ActionMethods(driver);
    }

    @AfterTest
    void closeBrowser(){
         driver.quit();
    }


}
